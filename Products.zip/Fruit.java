//Erin Owens copyright 2024

public class Fruit extends Food {
	public Fruit(int id, String name, double price, double volume, int units) {
		super(id, name, price, volume);
		this.units = units;
	}
	public double price() {
		double price = (super.price() * units) / units;
		return price;
	}
	public String toString() {
		String fruit = "Fruit: " + super.toString() + " count: " + units;
		return fruit;
	}

private int units;
}

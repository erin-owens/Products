//Erin Owens Copyright 2024

public class Clothing extends Product{
	enum Size{
		XXS, XS, S, M, L, XL, XXL;
	}
	public Clothing(int id, String name, double price, Size size, String material){
		super(id, name, price);
		this.size = size;
		this.material = material;
	}
	public String toString() {
		String article = super.toString() + ", Size: " + size + ", Material: " + material;
		return article;
	}

private Size size;
private String material;
}

//Erin Owens copyright 2024

public class Furniture extends Product{
	enum Material{
		Wood, Plastic, Metal, Fabric, Leather, Other;
	}
	enum Location{
		LivingRoom,
		Bathroom,
		DiningRoom;
	}
	public Furniture(int id, String name, double price, String dimensions, double weight, Material material, Location location){
		super(id, name, price);
		this.dimensions = dimensions;
		this. weight = weight;
		this.material = material;
		this.location = location;		
	}
	public String toString() {
		String formatWeight = String.format("%.2f", weight);
		String furniture = super.toString() + ", Dimensions: " + dimensions + ", Weight: " + formatWeight 
				+ " kg, Material: " + material + ", Location: " + location;
		return furniture;
	}
	
	
private String dimensions;
private double weight;
private Material material;
private Location location;

}

//Erin Owens copyright 2024
/**
 * The Product class stores information about a purchasable item in an
 * online shopping application. It contains information identifying,
 * naming, and providing a price for some item.
 */
public class Product{
	//public (?)

	/**
	 * 
	 * @param id : product id >= 0
	 * @param name : must not be empty
	 * @param price : must be > 0.0
	 */
	
	public Product(int id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
	}
	/**
	 * id accessor
	 * 
	 * @return product id as integer
	 */
	public int id(){
		return id;
	}
	
	/**
	 * name accessor
	 * 
	 * @return product name as as String
	 */
	public String name() {
		return name;
	}
	
	/**
	 * price accessor
	 * 
	 * @return product price as double
	 */
	public double price() {
		return price;
	}
	
	/**
	 * Method equals(Product rhs), where equality is determined solely by
	 * equal ids. That is, if two products have different ids, they are 
	 * not equal.
	 * 
	 * @param rhs The right-hand-side of this == rhs
	 * @return True when the id of two products are equal.
	 */
	boolean equals(Product rhs) {
		if(rhs.id == id) {
			return true;
		}
		return false;
	}
	
	/**
	 * When rendering a Product instance as a string, use the following rules:
	 *  1. If an instance name contains a space character, it must be surrounded by
	 *     double quotes, e.g. Cellphone charger -> "Cellphone charger"
	 *  2. Each attribute must be printed in order: id, name, price. They are delimited
	 *     by a single comma (,) followed by a space with nothing at the end.
	 *  3. The id must always be 10 characters wide and use 0s to left-pad if less than 10,
	 *     e.g., 1234 -> 0000001234 
	 *     *use %f command "%10d", decimal
	 *  4. The price must be rounded to two decimal places, representing cents, and be
	 *     preceded by a dollar sign ($), e.g. 5.705 -> $5.71
	 */
	public String toString() {
		String newName = " ";
		for(int i = 0; i < name.length(); i++) {
		 if(name.contains(" ")){
		 newName = ("\"" + name + "\"");	
		 break;
		 }else {
			 newName = name;
		 }
		 
		}
		String ID = Integer.toString(id);
		if(ID.length() < 10) {
			ID = String.format("%010d", id);
		}
		String Price = String.format("%.2f", price);
		String productInstance = (ID + ", " + newName + ", $" + Price);
		return productInstance;
	}
private int id;
private String name;
private double price;
}
//Erin Owens copyright 2024

public class Food extends Product{
	public Food(int id, String name, double price, double volume) {
		super(id, name, price);
		this.volume = volume;
	}
	public double price() {
		double price = super.price() * volume;
		return price;
	}
	
	
	public String toString() {
		String total = String.format("%.2f", price());
		String foodItem = super.toString() +  ", Total: $" + total;
		return foodItem;
	}
	
private double volume;
}

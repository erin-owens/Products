//Erin Owens copyright 2024

public class SmartPhone extends Electronics {
	enum Type{
		Apple, Android, Other;
	}
	public SmartPhone(int id, String name, double price, int warrantyPeriod, Type type, boolean isBatteryPowered) {
		super(id, name, price, warrantyPeriod, isBatteryPowered);
		this.type = type;
	}
	public String toString() {
		String phone = type + " SmartPhone: " + super.toString();
		return phone;
	}	
private Type type;
}

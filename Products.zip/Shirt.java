//Erin Owens copyright 2024

public class Shirt extends Clothing{
	
	enum Sleeves{
		Short, Half, Long;
	}
	
	public Shirt(int id, String name, double price, Size size, String material, Sleeves sleeves) {
		super(id, name, price, size, material);
		this.sleeves = sleeves;		
	}
	public String toString() {
		String shirt = sleeves + "-Sleeved Shirt: " + super.toString();
		return shirt;
	}
	
private Sleeves sleeves;
}

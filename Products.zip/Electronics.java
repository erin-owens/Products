//Erin Owens copyright 2024

public class Electronics extends Product {
	public Electronics(int id, String name, double price, int warrantyPeriod, boolean isBatteryPowered){
		super(id, name, price);
		this.warrantyPeriod = warrantyPeriod;
		this.isBatteryPowered = isBatteryPowered;		
	}
	public String toString() {
		String battery;
		if(isBatteryPowered) {
			battery = "Yes";
		}else {
			battery = "No";
		}
		String device = super.toString() + ", Warranty: " + warrantyPeriod + " months, Battery: " + battery;
		return device;
	}
private int warrantyPeriod;
private boolean isBatteryPowered;
}

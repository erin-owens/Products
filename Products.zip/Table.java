//Erin Owens copyright 2024

public class Table extends Furniture {
	public Table(int id, String name, double price, String dimensions, double weight, Material material, Location location) {
		super(id, name, price, dimensions, weight, material, location);
	}
	public String toString() {
		String table = "Table: " + super.toString();
		return table;
	}

}
